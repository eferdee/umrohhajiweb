<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>@yield('title')</title>

    @vite(['resources/css/app.css','resources/js/app.js'])
</head>

<body class="bg-gray-100">

    @include('partials.admin.sidebar')

    <div class="ml-64 min-h-screen flex flex-col">

        @include('partials.admin.navbar')

        <main class="flex-1 p-6">

            @yield('content')

        </main>

        @include('partials.admin.footer')

    </div>

</body>
</html>