<aside class="fixed left-0 top-0 h-screen w-64 bg-white shadow">

    <div class="p-6 text-xl font-bold">
        Zafa Travel
    </div>

    <nav class="px-4">

        <a href="{{ route('admin.dashboard') }}" class="block py-2">
            Dashboard
        </a>

        <a href="#">
            Paket
        </a>

        <a href="#">
            Booking
        </a>

        <a href="#">
            Jamaah
        </a>

        <a href="#">
            Pembayaran
        </a>

        <a href="#">
            Artikel
        </a>

        <a href="#">
            Gallery
        </a>

        <a href="#">
            FAQ
        </a>

        <a href="#">
            Setting
        </a>

    </nav>

</aside>