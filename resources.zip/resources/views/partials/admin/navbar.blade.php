<header class="bg-white shadow h-16 flex justify-between items-center px-8">

    <h1 class="font-bold">
        @yield('title')
    </h1>

    <div class="flex items-center gap-4">

        <span>

            {{ auth()->user()->name }}

        </span>

        <form method="POST" action="{{ route('logout') }}">
            @csrf

            <button>
                Logout
            </button>

        </form>

    </div>

</header>