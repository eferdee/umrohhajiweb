<footer class="p-6 text-center text-gray-500">

    © {{ date('Y') }} Zafa Tour Travel

</footer>